%企业发展前景与运营波动
% clear;clc;close all;
%相关mat文件：P1.mat  P2_4.mat

j = 1;n = 1;
for i=1:length(T11)
    if(i==1 || (i>1 && T11(i,1) ~= T11(i-1,1)))
        n = 1;
    end
    if(i==1||(i>1 && T11(i,3) ~= T11(i-1,3)))
        I(j,1) = T11(i,1);%企业编号
        I(j,2) = T11(i,2);%年份
        I(j,3) = T11(i,3);%月份
        I(j,4) = T11(i,7);%进项加价税合计
        j = j+1;n = n + 1;
    else
        I(j-1,4) = I(j-1,4) + T11(i,7);%逐月累加进项加价税合计
    end
end

j = 1;n = 1;
for i=1:length(T12)
    if(i==1 || (i>1 && T12(i,1) ~= T12(i-1,1)))
        n = 1;
    end
    if(i==1||(i>1 && T12(i,3) ~= T12(i-1,3)))
        S(j,1) = T12(i,1);%企业编号
        S(j,2) = T12(i,2);%年份
        S(j,3) = T12(i,3);%月份
        S(j,4) = T12(i,7);%销项加价税合计
        j = j+1;n = n + 1;
    else
        S(j-1,4) = S(j-1,4) + T12(i,7);%逐月累加销项加价税合计
    end
end

%连接I与S
for i=1:length(I)
    for j=1:length(S)
        if(I(i,1) == S(j,1) && I(i,2) == S(j,2) && I(i,3) == S(j,3))
            I(i,5) = S(j,4);
            break;
        end
        I(i,5) = 0;%无销项加税总计记为0
    end
end

%流水计算
n = 1;h = 1;
for i=1:length(I)
    if((i>1&&I(i-1,1)~=I(i,1)))
        for j=1:n-1
            %I(i-j,7) = n-1;
            B(h,1) = n-1;%企业有效数据月数
        end
        n = 1;h = h+1;
    end
    I(i,6) = I(i,5) - I(i,4);%月流水计算
    n = n+1;
end
B(h,1) = n-1;

%企业发展趋势曲线拟合
for i=1:length(B)
    x = 1:B(i,1);
    h = polyfit(x,I(1:B(i,1),6),1);%企业发展趋势曲线拟合
    B(i,2) = h(1);%拟合系数k
    B(i,3) = h(2);%拟合系数b
end

%企业-月流水矩阵
n = 1;
for i=1:length(B)
    for j =1:B(i,1)
        Y(i,j) = I(n,6);
        n = n + 1;
    end
end

%残差（企业经营稳定程度）
for i=1:length(B)
    D = 0;
    for j =1:B(i,1)
        D = D + (Y(i,j)-(B(i,2)*j+B(i,3)))^2;
    end
    B(i,4) = D/B(i,1);
end




