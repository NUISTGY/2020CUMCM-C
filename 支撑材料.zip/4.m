%clear,clc,close all;
%相关mat文件：P2.mat

PA = 27/123;%评级为A的企业的概率
PB = 38/123;%评级为B的企业的概率
PC = 34/123;%评级为C的企业的概率
PD = 24/123;%评级为D的企业的概率

%违约情况系数估计
X=T0(:,3:3+7)';
X = mapminmax(X,0,1);%因子归一化
X = X';

for i=1:length(X)
   X(i,7 + 1) = 1;%构建常系数
end

for i=1:length(T0)%概率映射
    if (T0(i,1)==0)
        Z(i,1) = 96/123;%没有违约的概率
    else
        Z(i,1) = 27/123;%违约的概率
    end
end

Y = log(Z./(1-Z));
[b,bint,r,rint,stats] = regress(Y,X);%违约情况系数矩阵

%logit信誉级别系数估计
k = 8;%因子个数

X0=T0(:,2:2+k)';
X0 = mapminmax(X0,0,1);%因子归一化
X0 = X0';

for i=1:length(X0)
   X0(i,k + 1) = 1;%构建常系数
end

for i=1:length(T0)%概率映射
    if (T0(i,1)==4 || T0(i,1)==3)
        Z0(i,1)=PA + PB;%AB评级的总概率
    else
        Z0(i,1)=PC + PD;%CD评级的总概率
    end
end

Y0 = log(Z0./(1-Z0));
[b0,bint,r0,rint0,stats0] = regress(Y0,X0);%第一次决策系数矩阵

%==========================================================
X1=T1(:,2:2+k)';
X1 = mapminmax(X1,0,1);%因子归一化
X1 = X1';
for i=1:length(X1)
   X1(i,k + 1) = 1;%构建常系数
end

for i=1:length(T1)%概率映射
    if (T1(i,1)==4)
        Z1(i,1)=PA/(PA+PB);%A在AB的概率
    else
        Z1(i,1)=PB/(PA+PB);%B在AB的概率
    end
end

Y1 = log(Z1./(1-Z1));
[b1,bint,r1,rint1,stats1] = regress(Y1,X1);%%AB级别再决策系数矩阵

%====================================================
X2=T2(:,2:2+k)';
X2 = mapminmax(X2,0,1);%因子归一化
X2 = X2';
for i=1:length(X2)
   X2(i,k + 1) = 1;%构建常系数
end

for i=1:length(T2)%概率映射
    if (T2(i,1)==2)
        Z2(i,1)=PC/(PC+PD);%C在CD的概率
    else
        Z2(i,1)=PD/(PC+PD);%D在CD的概率
    end
end

Y2 = log(Z2./(1-Z2));
[b2,bint,r2,rint2,stats2] = regress(Y2,X2);%%CD级别再决策系数矩阵
%====================================================
