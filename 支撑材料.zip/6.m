%------利润模型------%
amt = [100 75 50 25];%分段额度
cnt = 168;%申请公司数
lev_ = [4 2 4 3 2 2 4 4 4 4 4 2 4 4 3 4 4 4 4 4 4 3 3 4 4 4 3 4 4 3 4 4 3 3 4 3 4 3 4 4 3 3 2 3 3 3 3 3 3 3 3 3 2 3 3 3 2 3 2 3 3 3 3 3 3 3 3 2 2 2 2 3 2 2 2 4 2 2 2 2 2 2 2 2 2 3 2 3 3 2 2 2 2 2 2 3 2 2 2];              %公司风险排序
lev = [4 4 4 4 3 3 4 3 3 3 3 3 3 3 3 3 3 3 3 3 3 4 3 3 3 3 3 3 3 3 3 4 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3];        %公司风险排序
MAX = 0;%最大利润
TOT = 1e4;%总金额
xx = [];
%遍历求解
for n1 = cnt:-1:0
    for n2 = (cnt-n1):-1:0
        for n3 = (cnt-n2-n1):-1:0
            tot = n1*amt(1)+n2*amt(2)+n3*amt(3)+(cnt-n1-n2-n3)*amt(4);
            if (tot == TOT)
                w = 0;
                for i = 1:cnt
                    %A级客户
                    if lev(i) == 4
                        if i <= n1
                            r = 0.0465;
                        elseif i <= n2+n1 && i > n1
                            r = 0.0745;
                        elseif i <= n3+n2+n1 && i> n1+n2
                            r = 0.0985;
                        elseif i <= cnt
                            r = 0.1265;
                        end
                    end
                    %B级客户
                    if lev(i) == 3
                        if i <= n1
                            r = 0.0585;
                        elseif i <= n2+n1
                            r = 0.0705;
                        elseif i <= n3+n2+n1
                            r = 0.0985;
                        elseif i <= cnt
                            r = 0.1265;
                        end
                    end
                    %C级客户
                    if lev(i) == 2
                        if i <= n1
                            r = 0.0585;
                        elseif i <= n2+n1
                            r = 0.0825;
                        elseif i <= n3+n2+n1
                            r = 0.0985;
                        elseif i <= cnt
                            r = 0.1265;
                        end
                    end
                    if i <= n1
                        w = w+amt(1)*r;
                    elseif i <= n2+n1
                        w = w+amt(2)*r;
                    elseif i <= n3+n2+n1
                        w = w+amt(3)*r;
                    elseif i <= cnt
                        w = w+amt(4)*r;
                    end
                end
                if w >= MAX
                    MAX = w;
                    MAX
                    N1 = n1
                    N2 = n2
                    N3 = n3
                    N4 = cnt - n1 - n2 - n3
                end
            end
        end
    end
end


