%------主成分决策模型------%
clc,clear
format long
data=load('sn1.txt');% 将原始数据保存到纯文本文件中
% data=load('sn2.txt');% sn1为问题一，sn2为问题二
[m,n]=size(data);
[data,mean,sigma]=zscore(data)% 数据标准化
r=corrcoef(data)% 生成相关系数矩阵
% 下面利用相关系数矩阵进行主成分分析，vec1的列为r的特征向量，即主成分的系数
[vec1,lamda,beta]=pcacov(r);% lamda为r的特征值，beta为各个主成分的信息贡献率
lamda,beta

f=repmat(sign(sum(vec1)),size(vec1,1),1);% 构造与x同维数的元素为正负1的矩阵
vec2=vec1.*f% 修改特征向量的正负号，每个特征向量乘以所有分量和的符号函数值

alpha=cumsum(beta) %计算累积贡献率alpha，第i个分量表示前i个主成分的累积贡献率
% 通过累积贡献率>=0.90自动选择主成分的个数，num为选取的主成分的个数
for num=1:n-1
    if(alpha(num)>=90.0)
        break; 
    end
end
num

df=data*vec2(:,[1:num]);% 计算各个主成分的得分
tf=df*beta(1:num)/100;% 计算综合得分
[stf,ind]=sort(tf,'descend');% 把得分按照从高到低的次序排列
stf=stf',ind=ind'
